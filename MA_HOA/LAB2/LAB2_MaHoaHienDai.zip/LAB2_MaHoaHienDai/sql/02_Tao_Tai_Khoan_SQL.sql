﻿-- 02_Tao_Tai_Khoan_SQL.sql
-- Chi dung tren may thuc hanh ca nhan.
-- Mat khau lab theo tai lieu: LabUser@2026
-- Chay lai tep nay bat cu luc nao cung duoc: no se DAT LAI dung mat khau tren.
USE master;
GO
IF SUSER_ID(N'lab2_user') IS NULL
    CREATE LOGIN lab2_user WITH PASSWORD = N'LabUser@2026', CHECK_POLICY = ON;
ELSE
    ALTER LOGIN lab2_user WITH PASSWORD = N'LabUser@2026';
GO
ALTER LOGIN lab2_user ENABLE;
GO
USE LAB2_MaHoaHienDai;
GO
IF DATABASE_PRINCIPAL_ID(N'lab2_user') IS NULL
    CREATE USER lab2_user FOR LOGIN lab2_user;
GO
IF IS_ROLEMEMBER(N'db_datareader', N'lab2_user') = 0
    ALTER ROLE db_datareader ADD MEMBER lab2_user;
IF IS_ROLEMEMBER(N'db_datawriter', N'lab2_user') = 0
    ALTER ROLE db_datawriter ADD MEMBER lab2_user;
GO
SELECT name AS user_trong_db, type_desc AS loai
FROM sys.database_principals WHERE name = N'lab2_user';
GO
